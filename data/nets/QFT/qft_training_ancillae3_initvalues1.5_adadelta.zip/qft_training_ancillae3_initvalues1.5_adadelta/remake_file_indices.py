import glob
import os
import shutil

files = glob.glob('./*.pickle')
prefix = os.path.commonprefix(files)
dirname = os.path.dirname(prefix)

def get_file_index(f):
    ext_len = len('.pickle')
    return int(f[len(prefix):-ext_len])

files = sorted(files, key=get_file_index)

for idx, f in enumerate(files):
    newidx = idx + 1
    if len(files) > 9:
        newidx = str(newidx).zfill(2)
    else:
        newidx = str(newidx)
    newname = 'newname_' + newidx + '.pickle'
    newname = os.path.join(dirname, newname)
    if os.path.isfile(newname):
        raise ValueError('"{}" already exists'.format(newname))
    print('Saving to "{}"'.format(newname))
    shutil.copyfile(f, newname)

