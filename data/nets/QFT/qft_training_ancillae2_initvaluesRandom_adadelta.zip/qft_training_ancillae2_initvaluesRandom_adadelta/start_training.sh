DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
LOCK_FILE="in_training"
LOCK_FILE_DIR="${DIR}/${LOCK_FILE}"
TRAINING_SCRIPT_DIR="${DIR}/../training_script.py"

if [ -f ${LOCK_FILE_DIR} ]; then
	printf "Another training seems to be ongoing. "
	printf "If not, delete the file \"${LOCK_FILE}\" to unlock the training.\n"
	exit 1
fi

echo "Training started on $(hostname)." > "${LOCK_FILE_DIR}"
# python -c "$(printf "import os\nwith open('${LOCK_FILE_DIR}', 'a'):\n\tos.utime('${LOCK_FILE_DIR}')\n\n")"
echo "$(cat ${LOCK_FILE_DIR})"


nohup bash -c "(\
python ${TRAINING_SCRIPT_DIR} \
	--n_attempts 20 --n_epochs 400 \
	--folder ${DIR} \
	--model_type 'all_interactions' \
	--model_name 'qft' \
	--num_qubits 3 --num_ancillae 2 \
	--sgd_method adadelta
	>> ${DIR}/log.txt\
)" >> ${DIR}/nohup.out &

rm ${LOCK_FILE_DIR}
