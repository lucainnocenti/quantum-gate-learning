DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
nohup bash -c "(\
python ./training_script.py --n_attempts 20 --n_epochs 400 \
	--initial_values 1 \
	--folder ${DIR} \
	--model_type 'all_interactions' \
	--model_name 'qft' \
	--num_qubits 3 --num_ancillae 1 \
	--sgd_method adadelta
	>> ${DIR}/log.txt\
)" > ${DIR}/nohup.out &
