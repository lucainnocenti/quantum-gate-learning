DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
LOCK_FILE="in_training"
TRAINING_SCRIPT_DIR="${DIR}/../training_script.py"

if [ -f ${DIR}/${LOCK_FILE} ]; then
	printf "Another training seems to be ongoing. "
	printf "If not, delete the file \"${LOCK_FILE}\" to unlock the training.\n"
	exit 1
fi

# echo "Training started on $(hostname)." > "${DIR}/${LOCK_FILE}"
python -c "$(printf "import os\nwith open('${DIR}/${LOCK_FILE}', 'a'):\n\tos.utime('${DIR}/${LOCK_FILE}')\n\n")"

nohup bash -c "(\
python ${TRAINING_SCRIPT_DIR} \
	--n_attempts 10 --n_epochs 400 \
	--initial_values 1 \
	--folder ${DIR} \
	--model_type 'all_interactions' \
	--model_name 'qft' \
	--num_qubits 3 --num_ancillae 3 \
	--sgd_method adadelta
	>> ${DIR}/log.txt\
)" >> ${DIR}/nohup.out &

rm ${DIR}/${LOCK_FILE}
